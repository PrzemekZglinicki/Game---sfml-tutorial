//
//  player.cpp
//  InstallingSFML
//
//  Created by Blank Blank on 2015-08-11.
//  Copyright (c) 2015 Blank Blank. All rights reserved.
//

#include "player.h"

player::player()
{
    rect.setSize(sf::Vector2f(32, 32));
    rect.setPosition(400, 200);
    rect.setFillColor(sf::Color::Blue);
}

void player::update()
{
    sprite.setPosition(rect.getPosition());
}

void player::updateMovement()
{
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
    {
        rect.move(0,-movementSpeed);
        sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 3, 32, 32));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
    {
        rect.move(0,movementSpeed);
        sprite.setTextureRect(sf::IntRect(counterWalking * 32, 0, 32, 32));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
    {
        rect.move(-movementSpeed,0);
        sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 1, 32, 32));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
    {
        rect.move(movementSpeed,0);
        sprite.setTextureRect(sf::IntRect(counterWalking * 32, 32 * 2, 32, 32));
    }
    
    counterWalking++;
    
    if (counterWalking == 2)
    {
        counterWalking = 0;
    }
}